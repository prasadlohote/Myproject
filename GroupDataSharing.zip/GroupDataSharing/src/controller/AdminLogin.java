package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class HackerLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter writer=response.getWriter();
		
			String email=request.getParameter("email");
			System.out.println(email);
		
			
		
			String password=request.getParameter("password");
			System.out.println(password);
			
			if(email.equals("admin") && password.equals("admin"))
			{
			
			
			RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
			rd.forward(request,response);
		}
		else {
			writer.println("Enter valid username and password");
			RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.jsp");
			rd.include(request,response);
		}
	}

}
