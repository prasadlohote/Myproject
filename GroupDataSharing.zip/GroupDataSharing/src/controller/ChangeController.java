package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connection.DataConnection;

/**
 * Servlet implementation class ChangeController
 */
@WebServlet("/ChangeController")
public class ChangeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
      
		String id=request.getParameter("id");
		String SID=id;
		String Query=request.getParameter("query");
		String SenderEmail=request.getParameter("SenderEmail");
		String ReceiverEmail=request.getParameter("ReceiverEmail");
		String Details=request.getParameter("Details");
		
		ArrayList<String>al=new ArrayList<>();
        al.add(Details);
        al.add(Query);
        String hash=al.toString();
        try
		    {
		    	MessageDigest md=MessageDigest.getInstance("SHA-256");
		    
			 
			byte[] hashInBytes = md.digest(hash.getBytes(StandardCharsets.UTF_8));
			 StringBuilder sb = new StringBuilder();
		     for (byte b : hashInBytes) {
		         sb.append(String.format("%02x", b));
		     }
		   String HashCode=sb.toString();
		
			
			Connection con=DataConnection.getConnection();
			String sql="insert into updatedata (SID, SenderEmail, ReceiverEmail, Query, Details,HashCode) values (?,?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, SID);
			ps.setString(2, SenderEmail);
			ps.setString(3, ReceiverEmail);
			ps.setString(4, Query);
			ps.setString(5, Details);
			ps.setString(6, HashCode);
			int i=ps.executeUpdate();
			if(i>0)
			{
				 
				   
				Connection con1=DataConnection.getConnection();
				String query="update cloudserver set Query=?,Details=? where id='"+id+"'";
				PreparedStatement ps1=con1.prepareStatement(query);
				ps1.setString(1, Query);
				ps1.setString(2, Details);
				
				
				
				int j=ps1.executeUpdate();
				
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Data update sucessfully..');");
				   out.println("location='EmployeeHome.jsp';");
				   out.println("</script>");
			}
			else
			{
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Incorrect Details..');");
				   out.println("location='EmpUpdate.jsp';");
				   out.println("</script>");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	 
	}

	
}
