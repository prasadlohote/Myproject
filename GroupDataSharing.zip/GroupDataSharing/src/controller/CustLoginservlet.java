package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CustBean;
import dao.LoginDao;

/**
 * Servlet implementation class CustLoginservlet
 */
@WebServlet("/EmpLogin")
public class CustLoginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
	RequestDispatcher rd=null;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 

		response.setContentType("text/html");
		PrintWriter writer=response.getWriter();
		
			String email=request.getParameter("email");
			System.out.println(email);
		
			
		
			String password=request.getParameter("password");
			System.out.println(password);
			
	

			if(LoginDao.validate(email, password))
			{
				
				HttpSession session=request.getSession();
				
				session.setAttribute("EmpEmail",email);
				
				
				RequestDispatcher rd=request.getRequestDispatcher("EmployeeHome.jsp");
				rd.forward(request,response);
			}
			else {
				writer.println("Enter valid username and password");
				RequestDispatcher rd=request.getRequestDispatcher("Employee.jsp");
				rd.include(request,response);
			}
		
		}

	}


