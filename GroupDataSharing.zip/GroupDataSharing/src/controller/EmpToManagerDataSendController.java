package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import connection.DataConnection;

/**
 * Servlet implementation class EmpToManagerDataSendController
 */
@WebServlet("/EmpToManagerDataSendController")
public class EmpToManagerDataSendController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		  HttpSession s2=request.getSession();
          String SenderEmail=(String)s2.getAttribute("EmpEmail");
          
        //id, SenderEmail, SenderRole, ReceiverEmail, ReceiverRole, Query, Details, HashCodes
          
          String SenderRole="Employee"; 
          String ReceiverEmail=request.getParameter("ManagerEmail");
          String ReceiverRole="Manager";
          
          String Query=request.getParameter("Query");
          String Details=request.getParameter("Details");
          ArrayList<String>al=new ArrayList<>();
          al.add(Details);
          al.add(Query);
          String hash=al.toString();
          try
		    {
		    	MessageDigest md=MessageDigest.getInstance("SHA-256");
		    
			 
			byte[] hashInBytes = md.digest(hash.getBytes(StandardCharsets.UTF_8));
			 StringBuilder sb = new StringBuilder();
		     for (byte b : hashInBytes) {
		         sb.append(String.format("%02x", b));
		     }
		   String HashCodes=sb.toString();
		
		   
		   Connection con=DataConnection.getConnection();
		  
		  String query="insert into cloudserver (SenderEmail, SenderRole, ReceiverEmail, ReceiverRole, Query, Details, HashCodes) values(?,?,?,?,?,?,?)";
	
		  PreparedStatement ps=con.prepareStatement(query);
		  ps.setString(1, SenderEmail);
		  ps.setString(2, SenderRole);
		  ps.setString(3, ReceiverEmail);
		  ps.setString(4, ReceiverRole);
		  ps.setString(5, Query);
		  ps.setString(6, Details);
		  ps.setString(7, HashCodes);
		  
		  int i=ps.executeUpdate();
		  
		  if(i>0)
		  {
			  Connection con1=DataConnection.getConnection();
			  
			  String query1="insert into proxyserver (SenderEmail, SenderRole, ReceiverEmail, ReceiverRole, Query, Details, HashCodes) values(?,?,?,?,?,?,?)";
		
			  PreparedStatement ps1=con1.prepareStatement(query1);
			  ps1.setString(1, SenderEmail);
			  ps1.setString(2, SenderRole);
			  ps1.setString(3, ReceiverEmail);
			  ps1.setString(4, ReceiverRole);
			  ps1.setString(5, Query);
			  ps1.setString(6, Details);
			  ps1.setString(7, HashCodes);
			  
			  int i1=ps1.executeUpdate();
			  if(i1>0)
			  {
			   out.println("<script type=\"text/javascript\">");
			   out.println("alert('Data send sucessfully..');");
			   out.println("location='EmployeeHome.jsp';");
			   out.println("</script>");
			  }
			  else
			  {
				   out.println("<script type=\"text/javascript\">");
				   out.println("alert('Data send Faild please try again..');");
				   out.println("location='EmpDataAdd.jsp';");
				   out.println("</script>");
			  }
		  }
		  
		    }
          catch (Exception e) {
			e.printStackTrace();
		}
	}


}