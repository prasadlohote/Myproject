package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import connection.DataConnection;

/**
 * Servlet implementation class StudentEnterOTP
 */
@WebServlet("/EmpEnterOTP")
public class EmpEnterOTP extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		HttpSession session=request.getSession();
		String id=(String)session.getAttribute("id");
		
		
		
		String OTP=request.getParameter("OTP");
		System.out.println(OTP);
		
		
		try {
			Connection con=DataConnection.getConnection();
			String query="select * from updatedata where id='"+id+"'";
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String CID=rs.getString(2);
				HttpSession se=request.getSession();
				se.setAttribute("CID", CID);
				String OTPP=rs.getString(8);
				System.out.println(OTPP);
				
				if(OTP.equals(OTPP))
				{
					   out.println("<script type=\"text/javascript\">");
					   out.println("alert('OTP verify sucessfully..');");
					   out.println("location='EmpRetrieveData.jsp';");
					   out.println("</script>");
				}
				else
				{
					   out.println("<script type=\"text/javascript\">");
					   out.println("alert('Incorrect OTP ..');");
					   out.println("location='EnterOTP.jsp';");
					   out.println("</script>");
				}
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		{
			
		}
				
		
		
		
	}

}
