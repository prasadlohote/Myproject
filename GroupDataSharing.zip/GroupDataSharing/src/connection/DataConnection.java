package connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DataConnection {
	public static String DBName="groupdataorg";
	public static String DBUSER="root";
	public static String DBPASSWORD="root";
	public static Connection con;
	
	public static Connection getConnection(){
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Registered....");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DBName,DBUSER,DBPASSWORD);
			System.out.println("Connection established....");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
			
	}	

}
